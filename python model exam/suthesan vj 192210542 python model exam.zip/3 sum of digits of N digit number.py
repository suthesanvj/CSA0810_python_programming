num=int(input("Enter the number:"))
Sum=0
temp=num
while temp>0:
 digit=temp%10
 Sum+=digit
 temp=temp//10
print("Sum of Digits:", Sum)
